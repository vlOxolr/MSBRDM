#ifndef RTTHREADS_THREAD_H
#define RTTHREADS_THREAD_H

#include <Threads/ThreadInfo.h>
#include <Threads/ThreadList.h>

#include <RtThreads/ThreadFunc.h>
#include <RtThreads/RtThread.h>
#include <RtThreads/ThreadFuncExt.h>

#include <QString>
#include <QStringList>
#include <QList>
#include <QVector>
#include <QThread>
#include <QMutex>
#include <QObject>

#include <time.h>

namespace RtThreads{

typedef Threads::ThreadInfo ThreadInfo;
typedef Threads::ThreadList ThreadList;

class Thread :
        public QObject,
        public ThreadFunc,
        public AbstractThread
{
    Q_OBJECT

public:
    static QList<ThreadInfo> threadInfoList();
    static ThreadList threadList();

    static bool saveThreadList(const QString& = "./ThreadList.txt");

    // the process id
    static int getpid();

    // tid of current thread
    static int gettid();

    enum ThreadMode
    {
        RtThreadMode = 0,
        QThreadMode,
    };


private:
    static QList<ThreadInfo> g_threadInfoList; // global thread list
    static QMutex g_threadListMutex;

private:
    ThreadInfo m_info;
    ThreadMode m_mode;
    bool m_started;

    ThreadFuncExt<QThread> m_qThread;
    ThreadFuncExt<RtThread> m_rtThread;
    AbstractThread* m_thread;

public:
    Thread(ThreadMode mode = QThreadMode,
           const QString& name = "thread",
           QObject* parent = 0);

    ~Thread();

    void setMode(ThreadMode mode);

    int tid() const;
    QString name() const;

    QThread* qThread();
    RtThread* rtThread();

    void start();

    // block for given number of ms on thread finished
    // use this to wait for finish with timeout
    bool wait(unsigned long time = ULONG_MAX);

    // handle with care, only use when clean exit of thread
    //  is NOT possible
    void terminate();

    bool isFinished() const;
    bool isRunning() const;
    bool isRtThread() const;


protected: 
   virtual void run();

    // use the following functions only within
    // the implementation of the run function!

    void sleep(unsigned long secs);
    void usleep(unsigned long usecs);

private:
    void addToList();
    void removeFromList();

    void threadFunc();

};

}

#endif  // RTTHREADS_THREAD_H
