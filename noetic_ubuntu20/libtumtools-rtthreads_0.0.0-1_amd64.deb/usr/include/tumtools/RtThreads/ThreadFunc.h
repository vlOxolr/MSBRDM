#ifndef RTHREADS_THREADFUNC_H
#define RTHREADS_THREADFUNC_H

namespace RtThreads{

class ThreadFunc
{
public:
    virtual void threadFunc(void) = 0;
    virtual ~ThreadFunc() = 0;
};

inline ThreadFunc::~ThreadFunc(){}

}

#endif // RTHREADS_THREADFUNC_H
