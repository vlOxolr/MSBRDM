#ifndef RTTHREADS_ABSTRACTTHREAD_H
#define RTTHREADS_ABSTRACTTHREAD_H

namespace RtThreads{

class Thread;

class AbstractThread
{
public:
    virtual ~AbstractThread() = 0;

    virtual void start() = 0;

    // block for given number of ms on thread finished
    // use this to wait for finish with timeout
    virtual bool wait(unsigned long time) = 0;

    // handle with care, only use when clean exit of thread
    //  is NOT possible
    virtual void terminate() = 0;

    virtual bool isFinished() const = 0;
    virtual bool isRunning() const = 0;

protected: 
    // use the following functions only within
    // the implementation of the run function!
    virtual void sleep(unsigned long secs) = 0;
    virtual void usleep(unsigned long usecs) = 0;

    friend class RtThreads::Thread;
};

inline AbstractThread::~AbstractThread(){}

}

#endif  // RTTHREADS_ABSTRACTTHREAD_H
