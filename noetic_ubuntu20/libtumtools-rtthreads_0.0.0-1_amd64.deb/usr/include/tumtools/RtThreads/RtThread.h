#ifndef RTTHREADS_RTTHREAD_H
#define RTTHREADS_RTTHREAD_H

#include <QString>
#include <QStringList>
#include <QList>
#include <QVector>
#include <QThread>
#include <QMutex>
#include <QObject>

#include <time.h>

namespace RtThreads{

class RtThread : public QObject
{
    Q_OBJECT

public:

private:
    int m_priority;
    int m_stackSize;
    int m_stackPreFaultSize;

    bool m_started;

    struct timespec m_t;
    pthread_t m_thread;
    pthread_attr_t m_attr;

public:
    RtThread(QObject* parent = 0,
             int priority = 49,
             int stackSize = 8*1024,
             int stackPreFaultSize = 8*1024);

    ~RtThread();

    void setPriority(int priority = 49);

    // stack size of the thread
    void setStackSize(int size = 8*1024); //bytes

    // must be smaller or equal to stack size
    //  otherwise max stack size
    void setStackPreFaultSize(int size = 8*1024); // bytes

    void start();

    // block for given number of ms on thread finished
    // use this to wait for finish with timeout
    bool wait(unsigned long time = ULONG_MAX);

    // handle with care, only use when clean exit of thread
    //  is NOT possible
    void terminate();

    bool isFinished() const;
    bool isRunning() const;

    int priority() const;

protected: 
   virtual void run() = 0;

    // use the following functions only within
    // the implementation of the run function!

    // time in seconds to sleep
    // call this function only within the run func.
    void sleep(unsigned long secs);
    void usleep(unsigned long usecs);

    double time() const; // s

private:
    // SCHED_RR
    // SCHED_FIFO
    //void pthread_setPriority(int sched = SCHED_RR, int prio = sched_get_priority_max(SCHED_RR));
    bool pthread_setPriority(int sched = SCHED_FIFO, int prio = 49);

    void pthread_initClock();
    void pthread_stackPrefault(int size); // size in bytes
    void pthread_lockMemory();

    // this is the pthread confrom func. is assigned in
    //  the pthread create func.
    static void *pthread(void* rtThread);

    // for init and deinit before calling run()
    void internal_run();

};

}

#endif  // RTTHREADS_RTTHREAD_H
