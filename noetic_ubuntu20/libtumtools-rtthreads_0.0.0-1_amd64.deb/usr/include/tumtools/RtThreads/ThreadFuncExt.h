#ifndef RTTHREADS_QTHREADWARPPER_H
#define RTTHREADS_QTHREADWARPPER_H

#include <QThread>
#include <RtThreads/RtThread.h>
#include <RtThreads/ThreadFunc.h>
#include <RtThreads/AbstractThread.h>

namespace RtThreads{

// test if type T is derived from type B
template<class T, class B> struct Derived_from {
    static void constraints(T* p) { B* pb = p; }
    Derived_from() { void(*p)(T*) = constraints; }
};


template<class T>     // a class with a virtual run function
class ThreadFuncExt : public T, public AbstractThread
{

public:

private:
    ThreadFunc* m_threadFunc;

public:
    ThreadFuncExt(QObject* parent = 0) : T(parent)
    {

    }

    ~ThreadFuncExt(){}

    void setThreadFunc(ThreadFunc* f)
    {
        m_threadFunc = f;
    }

    operator AbstractThread*()
    {
        return this;
    }

    virtual void start()
    {
        T::start();
    }


    virtual bool wait(unsigned long time = ULONG_MAX)
    {
        return T::wait(time);
    }

    virtual void terminate()
    {
        T::terminate();
    }

    virtual bool isFinished() const
    {
        return T::isFinished();
    }

    virtual bool isRunning() const
    {
        return T::isRunning();
    }

protected:
    virtual void run()
    {
        if(m_threadFunc != 0)
        {
            m_threadFunc->threadFunc();
        }
    }

    virtual void sleep(unsigned long secs)
    {
        T::sleep(secs);
    }

    virtual void usleep(unsigned long usecs)
    {
        T::usleep(usecs);
    }
};


}

#endif  // RTTHREADS_THREAD_H
