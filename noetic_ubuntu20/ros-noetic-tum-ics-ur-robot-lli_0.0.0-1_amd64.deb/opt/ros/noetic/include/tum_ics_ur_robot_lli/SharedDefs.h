#ifndef SHAREDDEFS_H
#define SHAREDDEFS_H

//#include<vector>
//#include<string>

namespace tum_ics_ur_robot_lli{

//#define URDOF 6


//enum ControlInterface
//{
//    POSITION_INTF,
//    VELOCITY_INTF,
//    EFFORT_INTF,
//    UNKNOWN_ITNF
//};

}

#endif // SHAREDDEFS_H
