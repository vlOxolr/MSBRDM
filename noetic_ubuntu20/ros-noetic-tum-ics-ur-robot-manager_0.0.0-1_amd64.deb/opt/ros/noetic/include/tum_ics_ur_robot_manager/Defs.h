#ifndef UR_ROBOT_MANAGER_DEFS_H
#define UR_ROBOT_MANAGER_DEFS_H

namespace tum_ics_ur_robot_manager{

}

#endif // UR_ROBOT_MANAGER_DEFS_H
