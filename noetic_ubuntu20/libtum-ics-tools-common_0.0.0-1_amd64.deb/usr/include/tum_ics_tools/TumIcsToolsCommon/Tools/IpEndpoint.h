#ifndef TUM_ICS_TOOLS_COMMON_IP_ENDPOINT_H
#define TUM_ICS_TOOLS_COMMON_IP_ENDPOINT_H

#include <qglobal.h>
#include <QVector>
#include <QString>

namespace tum_ics_tools{
namespace Tools{

class IpEndpointPrivate;

/*!
 * \brief The IP Endpoint class.
 *
 * Container class for ip v4 address and port.
 */
class IpEndpoint
{
protected:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PRIVATE(IpEndpoint)

    IpEndpointPrivate* d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    IpEndpoint(IpEndpointPrivate& d);

public:
    /*!
     * \brief Default constructor.
     *
     * Is identical to the any constructor.
     *  - ipAddr = 0.0.0.0
     *  - port = 0
    */
    static IpEndpoint Default();

    /*!
     * \brief Undefined constructor.
     *
     * Is identical to the any constructor.
     *  - ipAddr = 0.0.0.0
     *  - port = 0
    */
    static IpEndpoint Undefined();

    /*!
     * \brief Any constructor.
     *
     *  - ipAddr = 0.0.0.0
     *  - port = 0
    */
    static IpEndpoint Any();

    /*!
     * \brief IP address any (0.0.0.0).
     */
    static quint32 IpAddrAny();

    /*!
     * \brief Port any (0).
     */
    static quint16 PortAny();


    /*!
     * \brief Checks if the give ip endpoint string has a valid format.
     */
    static IpEndpoint fromString(const QString& ipEp, bool* ok=0);

    static quint32 ipAddrFromString(const QString& ipAddr);
    static quint16 portFromString(const QString& port);

public:

    /*!
     * \brief Default constructor.
     *
     * Is identical to the any constructor.
     *  - ipAddr = 0.0.0.0
     *  - port = 0
    */
    IpEndpoint(quint32 ipAddr=IpAddrAny(), quint16 port=PortAny());

    /*!
     * \brief Constructor.
     *
     * Falls back to Undefined on error.
     */
    IpEndpoint(const QString& ipAddr,quint16 port);

    /*!
     * \brief Constructor.
     *
     * Creates an Endpoint from a config string, e.g.:
     *  - "192.168.0.10:1336"
     *
     * Falls back to Undefined on error.
     */
    IpEndpoint(const QString& ipEndpoint);

    /*!
     * \brief Copy constructor.
     */
    IpEndpoint(const IpEndpoint& other);

    /*!
     * \brief Deconstructor.
     */
    virtual ~IpEndpoint();

    /*!
     * \brief Assignment operator.
     *
     * Note: This is strictly needed because there is a new operator
     * in the constructor of this class.
     */
    IpEndpoint& operator=(const IpEndpoint& other);


    /*!
     * \brief Equality operator.
     */
    bool operator== (const IpEndpoint& other) const;
    bool operator!= (const IpEndpoint& other) const;

    /*!
     * \brief Less than operator. Needed for QMap.
     */
    bool operator< (const IpEndpoint& other) const;


    /*!
     * \brief Checks if it is the any endpoint.
     */
    bool isAny() const;

    /*!
     * \brief Checks if it has the any ip addr.
     */
    bool hasIpAddrAny() const;

    /*!
     * \brief Checks if it has the any port.
     */
    bool hasPortAny() const;


    /*!
     * \brief The ip address and the port are defined.
     */
    bool isUnique() const;


    /*!
     * \brief Set ip addr.
     */
    bool setIpAddr(const QString& ipAddr);
    bool setIpAddr(quint32 ipAddr);


    /*!
     * \brief IP addr.
     */
    quint32& ipAddr();
    const quint32& ipAddr() const;

    /*!
     * \brief Access IP address bytes.
     *
     * Note: The index is not checked!
     * E.g. 192.168.0.1: ind = 0 <=> 192.
     */
    void setIpAddrByte(int ind, quint8 byte);
    quint8 ipAddrByte(int ind) const;

    /*!
     * \brief Port.
     */
    quint16& port();
    const quint16& port() const;


    /*!
     * \brief Creates a formated string.
     *
     * The format is: "<a>.<b>.<c>.<d>"
     */
    QString toIpAddrString() const;


    /*!
     * \brief Creates a formated string.
     *
     * The format is: "<a>.<b>.<c>.<d>:<port>"
     */
    QString toIpEndpointString() const;


    /*!
     * \brief Creates a human readable string for this class.
     *
     * The format is: "<a>.<b>.<c>.<d>:<port>"
     */
    QString toString() const;

};

}}

#endif // TUM_ICS_TOOLS_COMMON_IP_ENDPOINT_H
