#ifndef TUM_ICS_TOOLS_COMMON_CLASS_LOADER_H
#define TUM_ICS_TOOLS_COMMON_CLASS_LOADER_H

#include <qglobal.h>
#include <QString>

#include <Tools/IGenericClass.h>

namespace tum_ics_tools{
namespace Tools{

class ClassLoaderPrivate;

/*!
 * \brief The Class loader class.
 *
 * This class can load shared libs at runtime and can create
 * classes from the loaded lib.
 */
class ClassLoader
{
protected:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PRIVATE(ClassLoader)

    ClassLoaderPrivate* d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    ClassLoader(ClassLoaderPrivate& d);

public:

    /*!
     * \brief Default constructor.
    */
    ClassLoader(const QString& libFilePath = QString());

    /*!
     * \brief Deconstructor.
     */
    virtual ~ClassLoader();

    /*!
     * \brief Open and load the shared lib which contains the desired class to create.
     *
     * Uses the previously defined file path if the arg is empty.
     */
    bool open(const QString& libFilePath = QString());

    /*!
     * \brief Unload and close the shared lib.
     *
     * NOTE: this invalidates all the classes which might have been created.
     */
    bool close();

    bool isOpened() const;
    bool isClosed() const;

    /*!
     * \brief Create a new class of the loaded library and return a generic pointer.
     */
    IGenericClass* createClassGeneric();

    /*!
     * \brief Create a new class of the loaded library with the specified type.
     *
     * NOTE: You need to be sure that you use the right interface class type IClass.
     * NOTE: The class is allocated on the heap and the caller of this function
     * needs to free the class when needed.
     *
     * The return of a nullptr indicates that something went wrong.
     */
    template<class IClass>
    IClass* createClass()
    {
        return static_cast<IClass*>(createClassGeneric());
    }

private:
    /*!
     * \brief Not copyable.
     */
    ClassLoader(const ClassLoader& other);

    /*!
     * \brief Not assignable.
     */
    ClassLoader& operator=(const ClassLoader& other);
};

}}

#endif // TUM_ICS_TOOLS_COMMON_CLASS_LOADER_H
