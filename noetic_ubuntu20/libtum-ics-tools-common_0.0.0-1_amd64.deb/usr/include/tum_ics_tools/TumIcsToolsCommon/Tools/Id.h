#ifndef TUM_ICS_TOOLS_COMMON_ID_H
#define TUM_ICS_TOOLS_COMMON_ID_H

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The Id container class.
 *
 * Ids start at 1 and are always positive.
 */
class Id
{
public:

private:
    int m_id;

public:
    /*!
     * \brief Default constructor.
     */
    Id(int id = 0) :
        m_id(id)
    {}

    /*!
     * \brief Copy constructor.
     */
    Id(const Id& id) :
        m_id(id.m_id)
    {}

    /*!
     * \brief Conversion operator.
     */
    operator int&()
    {
        return m_id;
    }

    /*!
     * \brief Conversion operator.
     */
    operator const int&() const
    {
        return m_id;
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_ID_H
