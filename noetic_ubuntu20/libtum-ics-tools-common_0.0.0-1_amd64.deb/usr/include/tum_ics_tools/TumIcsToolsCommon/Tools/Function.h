#ifndef TUM_ICS_TOOLS_COMMON_FUNCTION_H
#define TUM_ICS_TOOLS_COMMON_FUNCTION_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

template<typename R>
class IFunction
{
public:
    virtual ~IFunction()
    {}

    virtual IFunction* copy() const = 0;
    virtual R operator()() = 0;
};


template<typename R, class C>
class MemberFunction :
        public IFunction<R>
{
public:
    typedef R (C::*Func)(void);

private:
    Func m_f;
    C* m_c;

public:
    MemberFunction(C* c, Func f) :
        m_f(f),
        m_c(c)
    {
    }

    MemberFunction(const MemberFunction& other) :
        m_f(other.m_f),
        m_c(other.m_c)
    {
    }

    MemberFunction* copy() const
    {
        return new MemberFunction(*this);
    }

    R operator()()
    {
        return (*m_c.*(m_f))();
    }
};

template<typename R, class C>
MemberFunction<R,C> build(C* c, R (C::*f)(void))
{
    return MemberFunction<R,C>(c,f);
}


template<typename R>
class StaticFunction :
        public IFunction<R>
{
public:
    typedef R (*Func)(void);

private:
    Func m_f;

    static R defaultFunc(void)
    {
        qWarning("Function: function undefined.");
        return R();
    }

public:
    StaticFunction(Func func) :
        m_f(func)
    {
    }

    StaticFunction(const StaticFunction& other) :
        m_f(other.m_f)
    {
    }

    StaticFunction* copy() const
    {
        return new StaticFunction(*this);
    }

    R operator()()
    {
        if(m_f == 0)
        {
            return defaultFunc();
        }
        return m_f();
    }
};


/*!
 * \brief Function class for zero arguments.
 *
 * 'R' is the function return type.
 */
template<typename R>
class Function
{
public:
    typedef R (*Func)(void);

private:
    IFunction<R>* m_f;

public:
    /*!
     * \brief Constructor for static functions and c functions.
     */
    Function(Func f = 0) :
        m_f(new StaticFunction<R>(f))
    {
    }

    /*!
     * \brief Constructor for general implicit conversions.
     */
    Function(const IFunction<R>& f) :
        m_f(f.copy())
    {
    }

    /*!
     * \brief Constructor for implicit conversions of Functor classes.
     */
    template<class C>
    Function(C& c) :
        m_f(new MemberFunction<R,C>(&c,&C::operator()))
    {
    }

    /*!
     * \brief Constructor for member functions
     */
    template<class C>
    Function(C* c, R (C::*f)(void)) :
        m_f(new MemberFunction<R,C>(c,f))
    {
    }

    /*!
     * \brief Copy constructor.
     */
    Function(const Function& other) :
        m_f(other.m_f->copy())
    {
    }

    ~Function()
    {
        delete m_f;
    }

    Function& operator=(const Function& other)
    {
//        qDebug("Function: Assignment op.");
        if(this == &other)
        {
            return *this;
        }

        delete m_f;
        m_f = other.m_f->copy();
        return *this;
    }

    R operator()()
    {
        return (*m_f)();
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_FUNCTION_H
