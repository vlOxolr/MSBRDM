#ifndef TUM_ICS_TOOLS_COMMON_FUNCTION1_H
#define TUM_ICS_TOOLS_COMMON_FUNCTION1_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

template<typename R, typename A1>
class IFunction1
{
public:
    virtual ~IFunction1()
    {}

    virtual IFunction1* copy() const = 0;
    virtual R operator()(A1 a1) = 0;
};

template<typename R, class C, typename A1>
class MemberFunction1 :
        public IFunction1<R,A1>
{
public:
    typedef R (C::*Func)(A1);

private:
    Func m_f;
    C* m_c;

public:
    MemberFunction1(C* c, Func f) :
        m_f(f),
        m_c(c)
    {
    }

    MemberFunction1(const MemberFunction1& other) :
        m_f(other.m_f),
        m_c(other.m_c)
    {
    }

    MemberFunction1* copy() const
    {
        return new MemberFunction1(*this);
    }

    R operator()(A1 a1)
    {
        return (*m_c.*(m_f))(a1);
    }
};

template<typename R, class C, typename A1>
MemberFunction1<R,C,A1> build(C* c, R (C::*f)(A1))
{
    return MemberFunction1<R,C,A1>(c,f);
}


template<typename R, typename A1>
class StaticFunction1 :
        public IFunction1<R,A1>
{
public:
    typedef R (*Func)(A1);

private:
    Func m_f;

    static R defaultFunc(A1 a1)
    {
        qWarning("StaticFunction1: function undefined.");
        return R();
    }

public:
    StaticFunction1(Func func) :
        m_f(func)
    {
    }

    StaticFunction1(const StaticFunction1& other) :
        m_f(other.m_f)
    {
    }

    StaticFunction1* copy() const
    {
        return new StaticFunction1(*this);
    }

    R operator()(A1 a1)
    {
        if(m_f == 0)
        {
            return defaultFunc(a1);
        }
        return m_f(a1);
    }
};


/*!
 * \brief Function class for 1 arguments.
 *
 * 'R' is the function return type.
 */
template<typename R, typename A1>
class Function1
{
public:
    typedef R (*Func)(A1);

private:
    IFunction1<R,A1>* m_f;

public:

    /*!
     * \brief Constructor for static functions and c functions.
     */
    Function1(Func f = 0) :
        m_f(new StaticFunction1<R,A1>(f))
    {
    }

    /*!
     * \brief Constructor for general implicit conversions.
     */
    Function1(const IFunction1<R,A1>& f) :
        m_f(f.copy())
    {
    }

    /*!
     * \brief Constructor for implicit conversions of Functor classes.
     */
    template<class C>
    Function1(C& c) :
        m_f(new MemberFunction1<R,C,A1>(&c,&C::operator()))
    {
    }

    /*!
     * \brief Constructor for member functions
     */
    template<class C>
    Function1(C* c, R (C::*f)(void)) :
        m_f(new MemberFunction1<R,C,A1>(c,f))
    {
    }

    /*!
     * \brief Copy constructor.
     */
    Function1(const Function1& other) :
        m_f(other.m_f->copy())
    {
    }

    ~Function1()
    {
//        qDebug("Function1 destroyed.");
        delete m_f;
    }

    Function1& operator=(const Function1& other)
    {
//        qDebug("Assignment op.");
        if(this == &other)
        {
            return *this;
        }

        delete m_f;
        m_f = other.m_f->copy();
        return *this;
    }

    R operator()(A1 a1)
    {
        return (*m_f)(a1);
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_FUNCTION1_H
