#ifndef TUM_ICS_TOOLS_COMMON_CONSOLE_READER_H
#define TUM_ICS_TOOLS_COMMON_CONSOLE_READER_H

#include <qglobal.h>
#include <QObject>

namespace tum_ics_tools{
namespace Tools{

class ConsoleReaderPrivate;

/*!
 * \brief The Interface class for a standard single tsu interface.
 */
class ConsoleReader :
        public QObject
{
    Q_OBJECT

protected:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PRIVATE(ConsoleReader)

    ConsoleReaderPrivate* d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    ConsoleReader(ConsoleReaderPrivate& d);

public:

public:
    /*!
     * \brief Default constructor.
     */
    explicit ConsoleReader(QObject* parent = 0);

    /*!
     * \brief Deconstructor.
     */
    ~ConsoleReader();

    /*!
     * \brief Checks if there is a line in the queue.
     */
    bool hasLine();

    /*!
     * \brief Gets the next line from the queue.
     */
    QString getLine(bool *ok);

private:
    /*!
     * \brief Not copyable.
     */
    ConsoleReader(const ConsoleReader& other);

    /*!
     * \brief Not assignable.
     */
    ConsoleReader& operator=(const ConsoleReader& other);


Q_SIGNALS:
    void newLine(QString line);

};

}}

#endif // TUM_ICS_TOOLS_COMMON_CONSOLE_READER_H
