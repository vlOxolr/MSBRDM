#ifndef TUM_ICS_TOOLS_UNIX_SUPPORT_H
#define TUM_ICS_TOOLS_UNIX_SUPPORT_H

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include <netinet/in.h>

#include <qglobal.h>

/*!
 * \brief Loop over EINTR errors.
 *
 * Loops a system call until there is no EINTR error.
 * The EINTR error can occurs during each system call when
 * the process is interrupted by a signal from the kernel.
 * Using this macro restarts the system call on such an error
 * to ensure that the call has been completed correctly.
 *
 * NOTE: This is a convenience macro defined in 'qcore_unix_p.h'.
 *
 */
#define EINTR_LOOP(var, cmd)                    \
    do {                                        \
        var = cmd;                              \
    } while (var == -1 && errno == EINTR)


namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief Open system call.
 *
 * NOTE: This is a convenience function defined in 'qcore_unix_p.h'.
 */
static inline int qt_safe_open(const char *pathname, int flags, mode_t mode = 0777)
{
    // force the file to close when process is started by calling "execve()".
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif

    int fd;
    EINTR_LOOP(fd, ::open(pathname, flags, mode));

    // force the file to close when process is started by calling "execve()".
#ifndef O_CLOEXEC
    if (fd != -1)
        ::fcntl(fd, F_SETFD, FD_CLOEXEC);
#endif

    return fd;
}

/*!
 * \brief Read system call.
 *
 * NOTE: This is a convenience function defined in 'qcore_unix_p.h'.
 */
static inline qint64 qt_safe_read(int fd, void *data, qint64 maxlen)
{
    qint64 ret = 0;
    EINTR_LOOP(ret, ::read(fd, data, maxlen));
    return ret;
}

/*!
 * \brief Write system call.
 *
 * NOTE: This is a convenience function defined in 'qcore_unix_p.h'.
 */
static inline qint64 qt_safe_write(int fd, const void *data, qint64 len)
{
    qint64 ret = 0;
    EINTR_LOOP(ret, ::write(fd, data, len));
    return ret;
}

/*!
 * \brief Close system call.
 *
 * NOTE: This is a convenience function defined in 'qcore_unix_p.h'.
 */
static inline int qt_safe_close(int fd)
{
    int ret;
    EINTR_LOOP(ret, ::close(fd));
    return ret;
}

/*!
 * \brief Socket system call.
 *
 * NOTE: This is a convenience function defined in 'qnet_unix_p.h'.
 */
static inline int qt_safe_socket(int domain, int type, int protocol, int flags = 0)
{
    Q_ASSERT((flags & ~O_NONBLOCK) == 0);

    int fd;
    int newtype = type | SOCK_CLOEXEC;

    if (flags & O_NONBLOCK)
        newtype |= SOCK_NONBLOCK;
    fd = ::socket(domain, newtype, protocol);

    return fd;
}

/*!
 * \brief Send message system call.
 *
 * NOTE: This is a convenience function defined in 'qnet_unix_p.h'.
 */
static inline int qt_safe_sendmsg(int sockfd, const struct msghdr *msg, int flags)
{
    // don't send SIGPIPE signal on stream orientated sockets (e.g. TCP) when
    //    the other end breaks the connection.
#ifdef MSG_NOSIGNAL
    flags |= MSG_NOSIGNAL;
#else
    qt_ignore_sigpipe();
#endif

    int ret;
    EINTR_LOOP(ret, ::sendmsg(sockfd, msg, flags));
    return ret;
}

/*!
 * \brief Receive system call.
 */
static inline ssize_t qt_safe_recv(int sockfd, void* buf, size_t len, int flags)
{
    ssize_t ret;
    EINTR_LOOP(ret, ::recv(sockfd, buf, len, flags));
    return ret;
}

/*!
 * \brief Receive message system call.
 *
 * NOTE: This is a convenience function defined in 'qnet_unix_p.h'.
 */
static inline int qt_safe_recvmsg(int sockfd, struct msghdr *msg, int flags)
{
    int ret;
    EINTR_LOOP(ret, ::recvmsg(sockfd, msg, flags));
    return ret;
}


}}



#endif // TUM_ICS_TOOLS_UNIX_SUPPORT_H
