#ifndef TUM_ICS_TOOLS_COMMON_CLASS_CREATOR_H
#define TUM_ICS_TOOLS_COMMON_CLASS_CREATOR_H

#include <qglobal.h>
#include <QString>

#include <Tools/IGenericClass.h>

namespace tum_ics_tools{
namespace Tools{

class ClassCreatorPrivate;

/*!
 * \brief The ClassCreator class.
 *
 * This class can load shared libs at runtime and can create
 * classes from the loaded lib. In contrast to the class loader,
 * this class creates only one instance of the loaded class and
 * manages its pointer.
 */
class ClassCreator
{
protected:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PRIVATE(ClassCreator)

    ClassCreatorPrivate* d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    ClassCreator(ClassCreatorPrivate& d);

public:

    /*!
     * \brief Default constructor.
    */
    ClassCreator(const QString& libFilePath, bool* ok = 0);

    /*!
     * \brief Deconstructor.
     */
    virtual ~ClassCreator();

    /*!
     * \brief Generic pointer to the created class.
     *
     * This pointer is 0 on error.
     * NOTE: the creation and deletion of the created class
     * is managed by this class. You should not delete
     * the class to which this pointer is pointing.
     */
    IGenericClass* genericClassPtr();


    /*!
     * \brief Interface class pointer to the created class.
     *
     * This pointer is 0 on error.
     * NOTE: the creation and deletion of the created class
     * is managed by this class. You should not delete
     * the class to which this pointer is pointing.
     */
    template<class IClass>
    IClass* classPtr()
    {
        return static_cast<IClass*>(genericClassPtr());
    }


private:
    /*!
     * \brief Not copyable.
     */
    ClassCreator(const ClassCreator& other);

    /*!
     * \brief Not assignable.
     */
    ClassCreator& operator=(const ClassCreator& other);
};

}}

#endif // TUM_ICS_TOOLS_COMMON_CLASS_CREATOR_H
