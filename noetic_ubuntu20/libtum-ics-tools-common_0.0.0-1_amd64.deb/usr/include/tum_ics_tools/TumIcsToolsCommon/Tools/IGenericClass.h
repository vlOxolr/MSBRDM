#ifndef TUM_ICS_TOOLS_COMMON_GENERIC_CLASS_H
#define TUM_ICS_TOOLS_COMMON_GENERIC_CLASS_H

#include <qglobal.h>
#include <QString>

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The interface class for dynamically created classes
 * from a runtime loaded shared library.
 *
 * NOTE: If you want to create a class dynamically from a runtime
 * loaded shared library, then that class needs to have
 * a virtual destructor.
 */
class IGenericClass
{
public:
    static QString ClassType()
    {
        return QString("tum_ics_tools::Tools::IGenericClass");
    }

public:
    /*!
     * \brief The class id to dentify the class such that its pointer
     * can be casted to the right interface class.
     */
    virtual QString classType() const
    {
        return ClassType();
    }

    virtual ~IGenericClass()
    {
//        qDebug("Destruct IGenericClass.");
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_GENERIC_CLASS_H
