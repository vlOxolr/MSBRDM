#ifndef TUM_ICS_TOOLS_COMMON_FUNCTION3_H
#define TUM_ICS_TOOLS_COMMON_FUNCTION3_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

template<typename R, typename A1, typename A2, typename A3>
class IFunction3
{
public:
    virtual ~IFunction3()
    {}

    virtual IFunction3* copy() const = 0;
    virtual R operator()(A1 a1, A2 a2, A3 a3) = 0;
};

template<typename R, class C, typename A1, typename A2, typename A3>
class MemberFunction3 :
        public IFunction3<R,A1,A2,A3>
{
public:
    typedef R (C::*Func)(A1,A2,A3);

private:
    Func m_f;
    C* m_c;

public:
    MemberFunction3(C* c, Func f) :
        m_f(f),
        m_c(c)
    {
    }

    MemberFunction3(const MemberFunction3& other) :
        m_f(other.m_f),
        m_c(other.m_c)
    {
    }

    MemberFunction3* copy() const
    {
        return new MemberFunction3(*this);
    }

    R operator()(A1 a1, A2 a2, A3 a3)
    {
        return (*m_c.*(m_f))(a1,a2,a3);
    }
};

template<typename R, class C, typename A1, typename A2, typename A3>
MemberFunction3<R,C,A1,A2,A3> build(C* c, R (C::*f)(A1,A2,A3))
{
    return MemberFunction3<R,C,A1,A2,A3>(c,f);
}


template<typename R, typename A1, typename A2, typename A3>
class StaticFunction3 :
        public IFunction3<R,A1,A2,A3>
{
public:
    typedef R (*Func)(A1,A2,A3);

private:
    Func m_f;

    static R defaultFunc(A1 a1, A2 a2, A3 a3)
    {
        qWarning("StaticFunction3: function undefined.");
        return R();
    }

public:
    StaticFunction3(Func func) :
        m_f(func)
    {
    }

    StaticFunction3(const StaticFunction3& other) :
        m_f(other.m_f)
    {
    }

    StaticFunction3* copy() const
    {
        return new StaticFunction3(*this);
    }

    R operator()(A1 a1, A2 a2, A3 a3)
    {
        if(m_f == 0)
        {
            return defaultFunc(a1,a2,a3);
        }
        return m_f(a1,a2,a3);
    }
};


/*!
 * \brief Function class for 1 arguments.
 *
 * 'R' is the function return type.
 */
template<typename R, typename A1, typename A2, typename A3>
class Function3
{
public:
    typedef R (*Func)(A1,A2,A3);

private:
    IFunction3<R,A1,A2,A3>* m_f;

public:

    /*!
     * \brief Constructor for static functions and c functions.
     */
    Function3(Func f = 0) :
        m_f(new StaticFunction3<R,A1,A2,A3>(f))
    {
    }

    /*!
     * \brief Constructor for general implicit conversions.
     */
    Function3(const IFunction3<R,A1,A2,A3>& f) :
        m_f(f.copy())
    {
    }

    /*!
     * \brief Constructor for implicit conversions of Functor classes.
     */
    template<class C>
    Function3(C& c) :
        m_f(new MemberFunction3<R,C,A1,A2,A3>(&c,&C::operator()))
    {
    }

    /*!
     * \brief Constructor for member functions
     */
    template<class C>
    Function3(C* c, R (C::*f)(void)) :
        m_f(new MemberFunction3<R,C,A1,A2,A3>(c,f))
    {
    }

    /*!
     * \brief Copy constructor.
     */
    Function3(const Function3& other) :
        m_f(other.m_f->copy())
    {
    }

    ~Function3()
    {
        delete m_f;
    }

    Function3& operator=(const Function3& other)
    {
        if(this == &other)
        {
            return *this;
        }

        delete m_f;
        m_f = other.m_f->copy();
        return *this;
    }

    R operator()(A1 a1, A2 a2, A3 a3)
    {
        return (*m_f)(a1,a2,a3);
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_FUNCTION3_H
