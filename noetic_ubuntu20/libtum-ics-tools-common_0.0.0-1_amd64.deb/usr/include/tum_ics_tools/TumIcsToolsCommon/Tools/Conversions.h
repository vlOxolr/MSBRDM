#ifndef TUM_ICS_TOOLS_CONVERSIONS_H
#define TUM_ICS_TOOLS_CONVERSIONS_H

#include <Eigen/Eigen>
#include <QString>

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The Conversions class.
 */
class Conversions
{
public:
    /*!
     * \brief Conversion func.
     */
    static Eigen::Vector3d toPosEigen(const Eigen::Affine3d& tf);

    /*!
     * \brief Conversion func.
     */
    static Eigen::Matrix3d toRotEigen(const Eigen::Affine3d& tf);

    /*!
     * \brief Conversion func.
     */
    static Eigen::Affine3d toPoseEigen(const Eigen::Matrix3d& rot,
                                       const Eigen::Vector3d& pos);
    /*!
     * \brief Conversion func.
     */
    static QString toString(const Eigen::MatrixXd& m);
    static QString toString(const Eigen::Affine3d& tf);


private:
    /*!
     * \brief Not instanciable (static class).
     */
    Conversions();
};



}}



#endif // TUM_ICS_TOOLS_CONVERSIONS_H
