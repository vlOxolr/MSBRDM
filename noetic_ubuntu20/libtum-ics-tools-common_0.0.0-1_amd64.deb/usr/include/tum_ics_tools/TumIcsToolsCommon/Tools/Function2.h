#ifndef TUM_ICS_TOOLS_COMMON_FUNCTION2_H
#define TUM_ICS_TOOLS_COMMON_FUNCTION2_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

template<typename R, typename A1, typename A2>
class IFunction2
{
public:
    virtual ~IFunction2()
    {}

    virtual IFunction2* copy() const = 0;
    virtual R operator()(A1 a1, A2 a2) = 0;
};

template<typename R, class C, typename A1, typename A2>
class MemberFunction2 :
        public IFunction2<R,A1,A2>
{
public:
    typedef R (C::*Func)(A1,A2);

private:
    Func m_f;
    C* m_c;

public:
    MemberFunction2(C* c, Func f) :
        m_f(f),
        m_c(c)
    {
    }

    MemberFunction2(const MemberFunction2& other) :
        m_f(other.m_f),
        m_c(other.m_c)
    {
    }

    MemberFunction2* copy() const
    {
        return new MemberFunction2(*this);
    }

    R operator()(A1 a1, A2 a2)
    {
        return (*m_c.*(m_f))(a1,a2);
    }
};

template<typename R, class C, typename A1, typename A2>
MemberFunction2<R,C,A1,A2> build(C* c, R (C::*f)(A1,A2))
{
    return MemberFunction2<R,C,A1,A2>(c,f);
}


template<typename R, typename A1, typename A2>
class StaticFunction2 :
        public IFunction2<R,A1,A2>
{
public:
    typedef R (*Func)(A1,A2);

private:
    Func m_f;

    static R defaultFunc(A1 a1, A2 a2)
    {
        qWarning("StaticFunction2: function undefined.");
        return R();
    }

public:
    StaticFunction2(Func func) :
        m_f(func)
    {
    }

    StaticFunction2(const StaticFunction2& other) :
        m_f(other.m_f)
    {
    }

    StaticFunction2* copy() const
    {
        return new StaticFunction2(*this);
    }

    R operator()(A1 a1, A2 a2)
    {
        if(m_f == 0)
        {
            return defaultFunc(a1,a2);
        }
        return m_f(a1,a2);
    }
};


/*!
 * \brief Function class for 1 arguments.
 *
 * 'R' is the function return type.
 */
template<typename R, typename A1, typename A2>
class Function2
{
public:
    typedef R (*Func)(A1,A2);

private:
    IFunction2<R,A1,A2>* m_f;

public:

    /*!
     * \brief Constructor for static functions and c functions.
     */
    Function2(Func f = 0) :
        m_f(new StaticFunction2<R,A1,A2>(f))
    {
    }

    /*!
     * \brief Constructor for general implicit conversions.
     */
    Function2(const IFunction2<R,A1,A2>& f) :
        m_f(f.copy())
    {
    }

    /*!
     * \brief Constructor for implicit conversions of Functor classes.
     */
    template<class C>
    Function2(C& c) :
        m_f(new MemberFunction2<R,C,A1,A2>(&c,&C::operator()))
    {
    }

    /*!
     * \brief Constructor for member functions
     */
    template<class C>
    Function2(C* c, R (C::*f)(void)) :
        m_f(new MemberFunction2<R,C,A1,A2>(c,f))
    {
    }

    /*!
     * \brief Copy constructor.
     */
    Function2(const Function2& other) :
        m_f(other.m_f->copy())
    {
    }

    ~Function2()
    {
        delete m_f;
    }

    Function2& operator=(const Function2& other)
    {
        if(this == &other)
        {
            return *this;
        }

        delete m_f;
        m_f = other.m_f->copy();
        return *this;
    }

    R operator()(A1 a1, A2 a2)
    {
        return (*m_f)(a1,a2);
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_FUNCTION2_H
