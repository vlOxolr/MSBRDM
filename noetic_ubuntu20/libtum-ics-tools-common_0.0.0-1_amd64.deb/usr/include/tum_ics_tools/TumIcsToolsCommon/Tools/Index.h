#ifndef TUM_ICS_TOOLS_COMMON_INDEX_H
#define TUM_ICS_TOOLS_COMMON_INDEX_H

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The Index container class.
 *
 *  Indices start at 0 and are always positive.
 */
class Index
{
private:
    int m_ind;

public:
    /*!
     * \brief Default constructor.
     */
    Index(int ind = 0) :
        m_ind(ind)
    {}

    /*!
     * \brief Copy constructor.
     */
    Index(const Index& ind) :
        m_ind(ind.m_ind)
    {}

    /*!
     * \brief Conversion operator.
     */
    operator int&()
    {
        return m_ind;
    }

    /*!
     * \brief Conversion operator.
     */
    operator const int&() const
    {
        return m_ind;
    }
};


}}

#endif // TUM_ICS_TOOLS_COMMON_INDEX_H
