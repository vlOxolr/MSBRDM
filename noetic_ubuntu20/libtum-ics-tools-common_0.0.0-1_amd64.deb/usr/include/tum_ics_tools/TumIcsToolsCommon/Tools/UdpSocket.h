#ifndef TUM_ICS_TOOLS_COMMON_UDP_SOCKET_H
#define TUM_ICS_TOOLS_COMMON_UDP_SOCKET_H

#include <qglobal.h>
#include <QObject>

#include <Tools/IpEndpoint.h>

namespace tum_ics_tools{
namespace Tools{

class UdpSocketPrivate;

/*!
 * \brief The UdpSocket class.
 *
 *
 * IDEAS:
 *  - use constant internal buffer for mulitiple packages to avoid allocation time on call of read multiple packages.
 *  - maybe even better: provide vector of byte arrays to read in and resize afterwards, no double copy needed!
 *  - but: large overhead if packet count is small.
 *  - so better: use static pre buffer and copy.
 */
class UdpSocket :
        public QObject
{
    Q_OBJECT

protected:
    /*!
     * \brief The macro for simple access to the private class.
     */
    Q_DECLARE_PRIVATE(UdpSocket)

    const QScopedPointer<UdpSocketPrivate> d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    UdpSocket(UdpSocketPrivate& d);

public:

public:
    /*!
     * \brief Default constructor.
     */
    explicit UdpSocket(QObject* parent = 0);

    /*!
     * \brief Deconstructor.
     */
    ~UdpSocket();



    /*!
     * \brief Check if current socket is valid.
     *
     * Valid = true <=> sd != -1
     */
    bool isValid() const;



    /*!
     * \brief Initialize a socket.
     *
     *  -> Check if current socket is valid (valid: sd != -1)
     *  -> If valid, then close current socket
     *  -> Create new socket by calling create()
     *  -> Set standard options:
     *      - boadcast: enabled
     *      - receive packet information: enabled
     *      - receive hop limit: enabled
     *      - address reusable: enabled
     *      - set default send/receive buffer sizes
     */
    bool initialize();


    /*!
     * \brief Bind the socket to the local port and ip.
     *
     * Bind the socket and enable the read notifier.
     *
     * NOTE: local <=> this PC, this program
     */
    bool bind(const IpEndpoint& local);


    /*!
     * \brief Checks if there are pending datagrams.
     *
     *  - peeks one byte into the next message
     *  - needs one system call
     */
    bool hasPendingDatagrams() const;

    /*!
     * \brief Gets the size of the next pending datagram.
     *
     *  - peeks into the next message and gets its size
     *  - needs one system call (in Linux!)
     */
    qint64 pendingDatagramSize() const;


    /*!
     * \brief Write a datagram.
     *
     * NOTE: The socket has to be bound before writing a datagram.
     */
    qint64 writeDatagram(const char *data,
                         qint64 size,
                         const QString& address,
                         quint16 port);

    /*!
     * \brief Read one packet.
     *
     * Reads one UDP datagram, one UDP packet.
     * Returns false on error, or when packet is bigger then maxSize.
     */
    bool read(QByteArray& pkt, int maxSize = 1500);

    /*!
     * \brief Close socket.
     *
     *  - deactivate all socket notifiers
     *  - close the socket
     *  - reset this class to the default state
     *
     * Close current socket. The socket becomes invalid.
     * The function initialize() has to be called to use the socket again.
     */
    bool close();

    /*!
     * \brief Get last error.
     */
    QString errorString() const;


public Q_SLOTS:

Q_SIGNALS:

private:
    /*!
     * \brief Not copyable.
     */
    UdpSocket(const UdpSocket& other);

    /*!
     * \brief Not assignable.
     */
    UdpSocket& operator=(const UdpSocket& other);



};

}}

#endif // TUM_ICS_TOOLS_COMMON_UDP_SOCKET_H
