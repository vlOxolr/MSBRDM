#ifndef TUM_ICS_TOOLS_COMMON_H
#define TUM_ICS_TOOLS_COMMON_H

#include <QMap>
#include <QPair>

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief Generates a valid reference when sth. fails.
 */
template <typename T>
static T& defaultReference()
{
    static T v;
    v = T(); // return always reference to default constructor;
    return v;
}

/*!
 * \brief Create map from key to index.
 */
template <class Key> QMap<Key,int>
static createMap(const QVector<Key>& keys)
{
    QMap<Key,int> map;
    for(int i=0; i<keys.size(); i++)
    {
        map.insert(keys.at(i),i);
    }
    return map;
}

/*!
 * \brief Init QMap with shift operator and QPairs.
 */
template <class Key, class T>
class InitQMap : public QMap<Key,T>
{
public:
    inline InitQMap<Key,T>& operator<< (const QPair<Key,T>& p)
    {
        insert(p.first,p.second);
        return *this;
    }

    /*!
     * \brief Pair with key and default value on error.
     */
    inline const QPair<Key,T> pair (const Key& key, const T& defaultValue=T()) const
    {
        return QPair<Key,T>(key,value(key,defaultValue));
    }
};


}}



#endif // TUM_ICS_TOOLS_COMMON_H
