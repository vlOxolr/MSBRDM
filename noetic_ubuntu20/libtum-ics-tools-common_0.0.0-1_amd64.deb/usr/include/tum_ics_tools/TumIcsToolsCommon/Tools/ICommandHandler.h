#ifndef TUM_ICS_TOOLS_COMMON_ICOMMAND_HANDLER_H
#define TUM_ICS_TOOLS_COMMON_ICOMMAND_HANDLER_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The interface class for Command Handlers.
 *
 * A class implementing this handler interface can use string based
 * commands to execute a desired behavior.
 */
class ICommandHandler
{
public:
    virtual ~ICommandHandler() = 0;

    /*!
     * \brief Handle the command and execute the desired behavior.
     */
    virtual bool handleCommand(const QString& cmd) = 0;

    /*!
     * \brief Description of the commands the implementing class supports.
     */
    virtual QString commandDescription() const = 0;
};

inline ICommandHandler::~ICommandHandler(){}

}}

#endif // TUM_ICS_TOOLS_COMMON_ICOMMAND_HANDLER_H
