#ifndef TUM_ICS_TOOLS_COMMON_SETTINGS_H
#define TUM_ICS_TOOLS_COMMON_SETTINGS_H

#include <qglobal.h>

#include <QMap>
#include <QVariant>

namespace tum_ics_tools{
namespace Tools{

class SettingsPrivate;

/*!
 * \brief The settings class.
 *
 * Like the QSettings class for copy/passing without persistent file.
 *  - Not thread save
 *  - No escape chars in keys
 *  - USED adjusted source code from QSettings.
 * URL: https://github.com/radekp/qt/blob/master/src/corelib/io/qsettings.cpp
 */
class Settings
{
protected:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PRIVATE(Settings)

    SettingsPrivate* d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    Settings(SettingsPrivate& d);

public:
    typedef QMap<QString,QVariant> SettingsMap;

    /*!
     * \brief Load settings from .ini file.
     */
    static bool load(SettingsMap& settingsMap, const QString& settingsFilePath);

    /*!
     * \brief Store settings in .ini file.
     */
    static bool save(const SettingsMap& settingsMap, const QString& settingsFilePath);

public:

    /*!
     * \brief Default constructor.
     */
    Settings(const SettingsMap& settingsMap = SettingsMap());

    /*!
     * \brief Constructor.
     *
     * Reads settings using QSettings. On error falls back to default constr.
     */
    Settings(const QString& settingsFilePath);

    /*!
     * \brief Copy constructor.
     */
    Settings(const Settings& other);

    /*!
     * \brief Deconstructor.
     */
    virtual ~Settings();

    /*!
     * \brief Assignment operator.
     *
     * Note: This is strictly needed because there is a new operator
     * in the constructor of this class.
     */
    Settings& operator=(const Settings& other);


    /*!
     * \brief Conversion operator.
     */
    operator const SettingsMap&() const;


    bool load(const QString& settingsFilePath);
    bool save(const QString& settingsFilePath) const;


    /*!
     * \brief Append prefix to current group.
     */
    void beginGroup(const QString& prefix);

    /*!
     * \brief Reset group back to previous one, before beginGroup() call.
     */
    void endGroup();

    /*!
     * \brief The current group; is empty when at root.
     */
    QString group() const;


    int beginReadArray(const QString& prefix);
    void beginWriteArray(const QString& prefix, int size = -1);
    void endArray();

    void setArrayIndex(int i);


    QStringList allKeys() const;

    /*!
     * \brief Get child key names of current group.
     */
    QStringList childKeys() const;

    /*!
     * \brief Get child group names of current group.
     */
    QStringList childGroups() const;


    /*!
     * \brief Set value in current group.
     */
    void setValue(const QString& key, const QVariant& value);

    /*!
     * \brief Remove value in current group.
     *
     * Note: removes all subkeys of the given key.
     * Note: empty key: current group, if no group remove all.
     */
    void remove(const QString& key);

    void clear();


    /*!
     * \brief Check if current group contains key.
     */
    bool contains(const QString& key) const;


    /*!
     * \brief Get value in current group.
     */
    QVariant value(const QString& key, const QVariant& defaultValue = QVariant()) const;


};

}}

#endif // TUM_ICS_TOOLS_COMMON_SETTINGS_H
