#ifndef TUM_ICS_TOOLS_COMMON_ITASK_H
#define TUM_ICS_TOOLS_COMMON_ITASK_H

#include <qglobal.h>

namespace tum_ics_tools{
namespace Tools{

/*!
 * \brief The interface class for Tasks.
 */
class ITask
{
public:
    virtual ~ITask() = 0;
    virtual bool execute() = 0;
};

inline ITask::~ITask(){}

}}

#endif // TUM_ICS_TOOLS_COMMON_ITASK_H
