#ifndef TUM_MATHTOOLS_H
#define TUM_MATHTOOLS_H

//#include<ros/ros.h>
#include<Math/EigenDefs.h>
#include<QDebug>


namespace Tum{
namespace Tools{

class MathTools
{
    //Vars
public:
    static const double u1_2;
    static const double u1_4;
    static const double u1_8;
    static const double u1_16;
    static const double u1_32;

    static const double u3_2;
    static const double u3_4;
    static const double u3_8;
    static const double u3_16;
    static const double u3_32;

    static Vector3d Z3();//0,0,0
    static Vector3d Zz();//0,0,1
    static Vector4d Z4();//0,0,0,0
    static Vector4d Zh();//0,0,0,1

    static Matrix3d Rx(double theta_rad);
    static Matrix3d Ry(double theta_rad);
    static Matrix3d Rz(double theta_rad);
    static Matrix3d Rzyx(double theta_rad, double beta_rad, double alpha_rad);
    static Matrix3d Rzyx(const Vector3d &a_rad);

    static Matrix3d Sw(const Vector3d &w);
    static Matrix3d Sw(double w0, double w1, double w2);

    // skew symmetric matrix of vector w for cross(w,y) = Sw_h * y
    static Matrix4d Sw_h(const Vector3d& w);


    // get x,y,z,t of a homogeneous transformation matrix T (returns const Vector3d&)
    static const Eigen::Block<const Eigen::Matrix4d, 3, 1> x(const Eigen::Affine3d& T);
    static const Eigen::Block<const Eigen::Matrix4d, 3, 1> y(const Eigen::Affine3d& T);
    static const Eigen::Block<const Eigen::Matrix4d, 3, 1> z(const Eigen::Affine3d& T);
    static const Eigen::Block<const Eigen::Matrix4d, 3, 1> t(const Eigen::Affine3d& T);


    static Matrix3d Rxd(double theta_deg);
    static Matrix3d Ryd(double theta_deg);
    static Matrix3d Rzd(double theta_deg);
    static Matrix3d Rzyxd(double theta_deg, double beta_deg, double alpha_deg);
    Matrix3d Rzyxd(const Vector3d &a_deg);

    static void Vector2ADouble(VectorDOFd &in, VDouble &out);
    static void ADouble2Vector(VDouble &in, VectorDOFd &out);


    static Vector3d GetEulerAngles(const Matrix3d &R, double sign, double phi_old);
    static void ContinuousEuler(Vector3d &eulerAd, Vector3d &eulerAd_Old);
    static void FilterButter(Vector3d &x, Vector3d &xf, const Vector3d &bButter, const Vector3d &aButter);

    static Matrix3d Bmat(Vector3d eulerAngles);


    static VVectorDOFd getJointPVT5(const VectorDOFd& start, const VectorDOFd& goal, double t_current, double t_total);

    template <typename R, typename T>
    static R getSpline5(const T &start, const T &goal, double t_current, double t_total);


    static Vector3d getJointPVT5(const double start, const double goal, double t_current, double t_total);

    static void IntHeun(double x, double x_1, double ix_1, double &ix, double midh);

protected:
    MathTools();
    //Funcs
public:
    //~MathTools();


private:

};


}
}

#endif // TUM_MATHTOOLS_H
