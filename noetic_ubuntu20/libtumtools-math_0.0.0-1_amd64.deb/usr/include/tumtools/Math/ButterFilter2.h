/*****************************************************************************//**
    @file butter2_class.h

    Header for class for 2nd order butterworth filter Butter2

    August 2015, Jun Nakanishi
**********************************************************************************/
#ifndef TUM_BUTTERFILTER2_CLASS_H
#define TUM_BUTTERFILTER2_CLASS_H

#include<Math/EigenDefs.h>

#include<QString>
#include<QDebug>

namespace Tum{
namespace Tools{

class Butter2{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

private:
    QString m_errorString;
    bool m_error;

    double m_cutoff; // cutoff frequency (Hz)
    double m_T;      // sampling period (sec)

    // internal filter variables
    Vector3d m_vx; ///< contains x[k], x[k-1], x[k-2]
    Vector3d m_vy; ///< contains y[k], y[k-1], y[k-2]

    //filter coefficients (b: num, a: den, same notation as in matlab)
    Vector3d m_a; ///< filter coefficients: den
    Vector3d m_b; ///< filter coefficients: num


    VVector3d m_vX;
    VVector3d m_vY;
    VectorDOFd m_Xf;

    bool m_firstTime; ///< firsttime flag
    bool m_vFirstTime; ///< firsttime flag

public:
    // constcuctor
    Butter2();
    Butter2(double coff, double sampleT);
    ~Butter2();

    bool error() const;
    const QString& errorString() const;

    void getCoefficients();
    void setFilterParams(double coff, double sampleT);
    double filter(double x);
    const VectorDOFd &filter(const VectorDOFd &x);
};

}//ns RobotTools
}//ns ur_robot_lli

#endif // TUM_BUTTERFILTER2_CLASS_H
