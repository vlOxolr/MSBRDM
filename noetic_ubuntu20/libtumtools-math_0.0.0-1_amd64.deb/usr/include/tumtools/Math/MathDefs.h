#ifndef MATHDEFS_H
#define MATHDEFS_H

#include <QVector>

namespace Tum{

#define DEG2RAD(DEG) ((DEG)*((M_PI)/(180.0)))
#define RAD2DEG(RAD) ((RAD)*((180.0)/(M_PI)))

#define STD_DOF 6

//We cannot use only QVector because ros::param::get receives std::vector<*>
typedef std::vector<double> VDouble;
typedef std::vector<int> VInt;
typedef std::vector<std::string> VString;
typedef std::vector<bool> VBool;


typedef QVector<QString> VQString;
typedef QVector<double> VQDouble;
typedef QVector<int> VQInt;
typedef QVector<std::string> VQStdString;
typedef QVector<bool> VQBool;

}

#endif // MATHDEFS_H
