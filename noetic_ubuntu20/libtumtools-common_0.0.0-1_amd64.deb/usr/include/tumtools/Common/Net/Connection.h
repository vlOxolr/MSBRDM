#ifndef TUM_TOOLS_COMMON_NET_CONNECTION_H
#define TUM_TOOLS_COMMON_NET_CONNECTION_H


#include <QString>
#include <Common/Net/Endpoint.h>

namespace Tum{
namespace Tools{
namespace Common{
namespace Net{

class Connection
{
public:
    enum ConnectionType
    {
        UNDEFINED_CONNECTION = -1,
        TCP_CONNECTION = 0,
        UDP_CONNECTION
    };

    static Connection Undefined();  // == Default Constructor

    // swaps local and remote
    static Connection swap(const Connection& c);
    static QString toString(ConnectionType t);

private:
    Endpoint m_local;           // local process, local pc
    Endpoint m_remote;          // process connected to, remote pc
    ConnectionType m_type;
    QString m_intf;             // optional interface name (e.g. eth1, lo, ...)

public:
    Connection(const Endpoint& local = Endpoint(),
               const Endpoint& remote = Endpoint(),
               ConnectionType type = UNDEFINED_CONNECTION,
               const QString& intf = "");

    Connection(const Connection& c, const QString& intf);

    Connection(const Connection& c);
    ~Connection();

    // swaps remote and dest of this connection
    Connection& swap();

    // local == local, remote == remote, type == type
    bool operator== (const Connection& other) const;
    bool operator!= (const Connection& other) const;

    bool operator< (const Connection& other) const;

    bool isDefined() const;     // type != UNDEFINED_CONNECTION
    bool isUndefined() const;   // type == UNDEFINED_CONNECTION

    /** checks if a given connection is the remote connection of this local connection
            local() = other.remote()
            remote() = other.local()
       -> if one endpoint is not unique then this function returns false!
    */
    bool isRemote(const Connection& other) const;

    // both, local and remote endpoints are fully defined
    bool isP2P() const;

    ConnectionType type() const;
    QString typeString() const;

    const Endpoint& local() const;
    const Endpoint& remote() const;

    const QString& intf() const;

    QString toString() const;

private:


};

}}}}


#endif  // TUM_TOOLS_COMMON_NET_SOCKET_CONNECTION_H
