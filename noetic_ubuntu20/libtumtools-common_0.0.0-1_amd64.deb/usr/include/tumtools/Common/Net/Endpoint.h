#ifndef TUM_TOOLS_COMMON_NET_ENDPOINT_H
#define TUM_TOOLS_COMMON_NET_ENDPOINT_H


#include <QString>
#include <QHostAddress>

namespace Tum{
namespace Tools{
namespace Common{
namespace Net{

class Endpoint
{

public:
    static QHostAddress IpAddrAny();    // 0.0.0.0
    static quint16 PortAny();           // 0
    static Endpoint Any();              // 0.0.0.0:0

private:
    QHostAddress m_addr;
    quint16 m_port;

public:
    // only use ip v4 addresses!
    Endpoint(); // default is any

    Endpoint(const QString& ipAddr, quint16 port);
    Endpoint(const QHostAddress& ipAddr, quint16 port);
    Endpoint(const Endpoint& ep);
    ~Endpoint();

    // addr == addr, port == port
    bool operator== (const Endpoint& other) const;
    bool operator!= (const Endpoint& other) const;

    // only works for ip v4 addresses
    bool operator< (const Endpoint& other) const;

    bool isAny() const;

    bool hasIpAddrAny() const;
    bool hasPortAny() const;

    // ip address and port defined and not any
    bool isUnique() const;

    const QHostAddress& ipAddr() const;
    quint16 port() const;

    QString toString() const;

private:

};

}}}}


#endif  // TUM_TOOLS_COMMON_NET_ENDPOINT_H
