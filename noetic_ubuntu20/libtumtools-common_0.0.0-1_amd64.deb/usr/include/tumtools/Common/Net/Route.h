#ifndef TUM_TOOLS_COMMON_NET_ROUTE_H
#define TUM_TOOLS_COMMON_NET_ROUTE_H

#include <QString>
#include <QHostAddress>

namespace Tum{
namespace Tools{
namespace Common{
namespace Net{

class Route
{
public:
    static QHostAddress IpAddrAny();    // 0.0.0.0
    static Route LocalLoopback();       // Route("lo", "127.0.0.0", "0.0.0.0", "255.255.0.0")

private:
    QString m_intf;
    QHostAddress m_dest;
    QHostAddress m_gateway;
    QHostAddress m_mask;

public:
    // only use ip v4 addresses!
    Route(const QString& intf = "undefined",
          const QString& dest = "0.0.0.0",
          const QString& gateway = "0.0.0.0",
          const QString& mask = "0.0.0.0");

    Route(const QString& intf,
          const QHostAddress& dest,
          const QHostAddress& gateway,
          const QHostAddress& mask);

    Route(const Route& r);
    ~Route();

    // intf == intf, dest == dest, gateway == gateway, mask == mask,
    bool operator== (const Route& other) const;
    bool operator!= (const Route& other) const;

    // only works for ip v4 addresses
    bool operator< (const Route& other) const;

    bool isDefined() const;
    bool isUndefined() const;

    // is the route to the local network
    // dest is not any, gateway is any, mask is not any
    bool isLocal() const;

    // default route: if no other route can be found then
    // use this route to forward to gateway
    // dest is any, gateway is not any, mask is any
    bool isDefault() const;

    bool hasValidMask() const;

    // check if given dest ip address is routed by this route
    bool routes(const QString& ipAddr) const;
    bool routes(const QHostAddress& ipAddr) const;

    // undefined, -1 on invalid subnet mask
    int hostBits() const;
    int subNetBits() const;

    QString cidr() const;

    const QString& intf() const;
    const QHostAddress& dest() const;
    const QHostAddress& gateway() const;
    const QHostAddress& mask() const;

    QString toString() const;

private:


};

}}}}


#endif  // TUM_TOOLS_COMMON_NET_ROUTE_H
