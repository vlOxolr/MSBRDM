#ifndef TUM_TOOLS_COMMON_ID_H
#define TUM_TOOLS_COMMON_ID_H

namespace Tum{
namespace Tools{
namespace Common{


class Id
{
private:
    int m_id;
public:
    Id(int id) : m_id(id){}
    Id(const Id& id) : m_id(id.m_id){}

    operator int&()
    {
        return m_id;
    }

    operator const int&() const
    {
        return m_id;
    }
};


}}}

#endif // TUM_TOOLS_COMMON_ID_H
