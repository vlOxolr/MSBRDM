#ifndef TUM_TOOLS_COMMON_H
#define TUM_TOOLS_COMMON_H

#include <Common/ConsoleReader.h>

#endif  // TUM_TOOLS_COMMON_H
