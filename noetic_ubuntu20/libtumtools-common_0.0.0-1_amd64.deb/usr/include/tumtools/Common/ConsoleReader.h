#ifndef TUM_TOOLS_COMMON_CONSOLEREADER_H
#define TUM_TOOLS_COMMON_CONSOLEREADER_H


#include <QObject>
#include <QSocketNotifier>
#include <QThread>
#include <QMutex>
#include <QQueue>

#include <unistd.h>

namespace Tum{
namespace Tools{
namespace Common{

class ConsoleReader : public QObject
{
    Q_OBJECT

private:
    QSocketNotifier m_notifier;
    QQueue<QString> m_queue;
    QMutex m_mutex;

public:
    explicit ConsoleReader(QObject* parent=0);
    ~ConsoleReader();

    bool hasLine();
    QString getLine(bool *ok);

private slots:
    void text();

signals:
    void message(QString s);


};

}}}

#endif // TUM_TOOLS_COMMON_CONSOLEREADER_H
